# GTNH 赛博监工 AstrBot 插件

当前版本：**0.2.0**

通过群聊查询 GTNH AE 网络中的物品种类和数量、查看 CPU 状态，并远程下单合成。

数据来源是 [RemoteOC-GTNH-AE2](https://github.com/z5882852/RemoteOC-GTNH-AE2)（赛博监工）的后端 API，OC 客户端仍然在游戏里运行。

## 安装

把整个 `astrbot_plugin_remoteoc_ae` 文件夹放到 AstrBot 的插件目录：

```
AstrBot/data/plugins/astrbot_plugin_remoteoc_ae/
```

然后在 AstrBot WebUI 的「插件」页重载插件，或重启 AstrBot。

插件里已经内置了 `item_names_zh.json.gz`（GTNH 2.8.0 的中文物品名对照表，约 380 KB），不需要额外下载。

依赖只有 `aiohttp`，一般 AstrBot 已经自带；如果没有，插件页安装依赖或手动：

```bash
pip install aiohttp
```

## 配置

在 AstrBot WebUI → 插件 → 本插件 → 配置：

| 配置项 | 说明 |
|---|---|
| `backend_url` | 赛博监工后端地址，默认 `http://127.0.0.1:8080` |
| `token` | 后端 `.env` 里的 `SERVER_TOKEN` |
| `client_id` | 对应 OC `client/env.lua` 的 `clientId`，默认 `client_01` |
| `item_data_url` | 可选，留空即可；只有想用前端最新的 `items_GTNH280.json` 覆盖内置中文表时才填，例如 `https://frp-jar.com:64274/items_GTNH280.json` |
| `request_timeout` | 等 OC 执行任务的超时，默认 60 秒 |
| `cache_ttl` | 物品列表缓存秒数，默认 120 |
| `page_size` | 每页物品数，默认 20 |
| `allowed_senders` | 允许使用的用户 ID，留空不限制 |
| `allowed_groups` | 允许使用的群 ID，留空不限制 |

### AstrBot 在 Docker 里怎么办

如果 AstrBot 和赛博监工后端不在同一个容器网络：

- Docker Desktop：`backend_url` 用 `http://host.docker.internal:8080`
- Linux Docker：启动 AstrBot 容器时加 `--add-host=host.docker.internal:host-gateway`，或直接填宿主机局域网 IP，如 `http://192.168.3.80:8080`

## 指令

| 指令 | 作用 |
|---|---|
| `/ae help` | 查看帮助 |
| `/ae status` | 后端版本、在线客户端、最后活动时间 |
| `/ae items [关键词] [页码]` | 查看物品种类和数量；不填关键词显示总数和前几页 |
| `/ae find <关键词>` | 搜索物品，显示注册名、damage、库存 |
| `/ae craft <物品> [数量] [CPU]` | 远程下单合成 |
| `/ae cpu` | 查看 CPU 空闲/忙碌、协处理器、存储 |
| `/ae cancel <CPU名>` | 取消该 CPU 当前合成 |
| `/ae refresh` | 强制刷新物品缓存 |

### 示例

```
/ae items
/ae items potato
/ae items 马铃薯          # 内置中文表，直接可用
/ae items minecraft:potato 2
/ae find baked
/ae craft minecraft:baked_potato 8
/ae craft "Baked Potato" 8 "CPU-1"
/ae cpu
/ae cancel "CPU-1"
```

物品名带空格时用引号，例如 `"Baked Potato"`；也可以用注册名 `minecraft:baked_potato`，更稳。

## 工作方式

插件调用赛博监工后端的任务接口：

1. `POST /api/task/task` 触发 `getAllItems` 等缓存任务；
2. OC 客户端按 8 秒轮询取任务、执行、上报；
3. 插件轮询 `GET /api/task/status` 直到 `completed`，解析结果；
4. 下单时用 `POST /api/task/add` 提交：

```lua
return ae.requestItem('物品名', damage, 数量, 'CPU名', 'label')
```

## 注意事项

- OC 必须在线（游戏里 `run.lua` 在跑），否则任务会等到超时。
- 中文物品名来自插件内置的 `item_names_zh.json.gz`（GTNH 2.8.0，约 5.2 万条），直接搜“马铃薯”即可；未收录的新物品会回退到游戏内英文 label 或注册名。
- 第一次 `/ae items` 或 `/ae refresh` 会触发一次全量扫描，通常需要几秒到十几秒。
- 物品列表有缓存；AE 网络变化后可以 `/ae refresh`。
- `/ae craft` 会真的在游戏里下单，注意 `allowed_senders` / `allowed_groups` 权限配置。
- 后端 token 是唯一鉴权，不要发到公开群或截图里。
- 本插件只做“查询 + 下单”，不修改 OC 端 Lua 文件。

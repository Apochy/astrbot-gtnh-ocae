"""AstrBot 插件：通过群聊访问 GTNH 赛博监工（RemoteOC-GTNH-AE2）。

功能：
- 查询 AE 网络中的物品种类和数量
- 搜索物品
- 查看 CPU 状态
- 远程下单合成
- 取消指定 CPU 的合成任务
"""

from __future__ import annotations

import asyncio
import gzip
import json
import re
import shlex
import time
from pathlib import Path
from typing import Any

try:
    from astrbot.api import AstrBotConfig, logger
except ImportError:  # 方便在 AstrBot 之外做静态检查
    AstrBotConfig = dict  # type: ignore
    logger = None  # type: ignore

try:
    from astrbot.api.event import AstrMessageEvent, filter
    from astrbot.api.star import Context, Star
except ImportError:  # 方便在 AstrBot 之外做静态检查
    AstrMessageEvent = Any  # type: ignore
    filter = None  # type: ignore
    Context = Any  # type: ignore

    class Star:  # type: ignore
        def __init__(self, context=None):
            self.context = context

try:
    from .remoteoc_api import RemoteOCClient, RemoteOCError
except ImportError:
    from remoteoc_api import RemoteOCClient, RemoteOCError


class RemoteOCAEPlugin(Star):
    """GTNH 赛博监工群聊控制插件。"""

    def __init__(self, context: Context, config: AstrBotConfig):
        super().__init__(context)
        self.config = config
        self.client = RemoteOCClient(
            base_url=str(config.get("backend_url", "http://127.0.0.1:8080")),
            token=str(config.get("token", "")),
            client_id=str(config.get("client_id", "client_01")),
            request_timeout=int(config.get("request_timeout", 60)),
        )
        self.page_size = max(5, int(config.get("page_size", 20)))
        self.cache_ttl = max(10, int(config.get("cache_ttl", 120)))
        self.max_chars = max(300, int(config.get("max_message_chars", 1800)))

        self._items: list[dict] = []
        self._items_at = 0.0
        self._items_lock = asyncio.Lock()
        self._craftables: list[dict] = []
        self._craftables_at = 0.0

        # 可选：前端 items_GTNH280.json，用于中文物品名
        self.item_data_url = str(config.get("item_data_url", "") or "").strip()
        self._zh_names: dict[str, str] = {}
        self._zh_loaded = False
        self._zh_lock = asyncio.Lock()

    async def terminate(self):
        await self.client.close()

    # ------------------------------------------------------------------ 工具
    @staticmethod
    def _sender_id(event: AstrMessageEvent) -> str:
        try:
            return str(event.get_sender_id())
        except Exception:
            sender = getattr(getattr(event, "message_obj", None), "sender", None)
            return str(getattr(sender, "user_id", ""))

    @staticmethod
    def _group_id(event: AstrMessageEvent) -> str:
        return str(getattr(getattr(event, "message_obj", None), "group_id", "") or "")

    def _allowed(self, event: AstrMessageEvent) -> bool:
        senders = [str(x) for x in (self.config.get("allowed_senders") or [])]
        groups = [str(x) for x in (self.config.get("allowed_groups") or [])]
        if groups and self._group_id(event) not in groups:
            return False
        if senders and self._sender_id(event) not in senders:
            return False
        return True

    def _tail(self, event: AstrMessageEvent, subcommand: str) -> str:
        """取出子命令后面的参数。

        AstrBot 可能传入完整消息（/ae items 土豆）或只传参数（土豆），两种都兼容。
        """
        text = (getattr(event, "message_str", "") or "").strip()
        text = re.sub(r"^[/!！。]\s*", "", text)
        parts = text.split()
        if parts and parts[0].lower() == "ae":
            parts = parts[1:]
        if parts and parts[0].lower() == subcommand.lower():
            parts = parts[1:]
        return " ".join(parts).strip()

    @staticmethod
    def _split(text: str) -> list[str]:
        try:
            return shlex.split(text)
        except ValueError:
            return text.split()

    def _chunks(self, text: str) -> list[str]:
        text = text.strip()
        if len(text) <= self.max_chars:
            return [text] if text else []
        chunks: list[str] = []
        current = ""
        for line in text.splitlines(keepends=True):
            if len(current) + len(line) > self.max_chars and current:
                chunks.append(current.rstrip("\n"))
                current = ""
            while len(line) > self.max_chars:
                chunks.append(line[: self.max_chars])
                line = line[self.max_chars:]
            current += line
        if current.strip():
            chunks.append(current.rstrip("\n"))
        return chunks

    def _send(self, event: AstrMessageEvent, text: str):
        for chunk in self._chunks(text):
            yield event.plain_result(chunk)

    @staticmethod
    def _count(item: dict) -> int | float:
        value: Any = item.get("size", item.get("amount", 0))
        try:
            number = float(value)
        except (TypeError, ValueError):
            return 0
        return int(number) if number.is_integer() else round(number, 2)

    @staticmethod
    def _ident(item: dict) -> str:
        return f"{item.get('name', '?')}:{int(item.get('damage', 0) or 0)}"

    def _zh(self, item: dict) -> str:
        key = f"{item.get('name', '')}:{int(item.get('damage', 0) or 0)}"
        return self._zh_names.get(key, "")

    def _label(self, item: dict) -> str:
        return self._zh(item) or str(item.get("label") or item.get("name") or "?")

    def _match(self, item: dict, keyword: str) -> bool:
        keyword = keyword.lower()
        fields = [
            self._zh(item),
            str(item.get("label", "")),
            str(item.get("name", "")),
            *[str(x) for x in (item.get("oreNames") or [])],
        ]
        return any(keyword in field.lower() for field in fields if field)

    def _exact(self, item: dict, keyword: str) -> bool:
        keyword = keyword.lower()
        return keyword in {
            self._zh(item).lower(),
            str(item.get("label", "")).lower(),
            str(item.get("name", "")).lower(),
        }

    @staticmethod
    def _parse_zh_payload(data: Any) -> dict[str, str]:
        """把 items_GTNH280.json 的嵌套结构压平成 name:damage -> zh。"""
        mapping: dict[str, str] = {}
        if not isinstance(data, dict):
            return mapping
        for name, damages in data.items():
            if not isinstance(damages, dict):
                continue
            for damage, info in damages.items():
                if isinstance(info, dict) and info.get("zh"):
                    mapping[f"{name}:{damage}"] = str(info["zh"])
        return mapping

    @staticmethod
    def _load_bundled_zh() -> dict[str, str]:
        """读取插件目录里内置的 item_names_zh.json.gz。"""
        path = Path(__file__).with_name("item_names_zh.json.gz")
        if not path.exists():
            return {}
        try:
            with gzip.open(path, "rt", encoding="utf-8") as file:
                data = json.load(file)
        except (OSError, ValueError) as exc:
            if logger:
                logger.warning(f"读取内置中文物品名失败: {exc}")
            return {}
        if isinstance(data, dict):
            return {str(key): str(value) for key, value in data.items()}
        return {}

    async def _load_zh_names(self) -> None:
        """加载中文物品名：优先内置表，item_data_url 可用于覆盖/更新。"""
        if self._zh_loaded:
            return
        async with self._zh_lock:
            if self._zh_loaded:
                return
            mapping = self._load_bundled_zh()
            if self.item_data_url:
                try:
                    data = await self.client.fetch_json(
                        self.item_data_url, timeout=120
                    )
                    mapping.update(self._parse_zh_payload(data))
                except RemoteOCError as exc:
                    if logger:
                        logger.warning(
                            f"从 item_data_url 更新中文物品名失败，继续使用内置表: {exc}"
                        )
            self._zh_names = mapping
            self._zh_loaded = True
            if logger:
                logger.info(f"中文物品名已加载: {len(mapping)} 条")

    async def _get_items(self, force: bool = False) -> list[dict]:
        async with self._items_lock:
            if (
                not force
                and self._items
                and time.time() - self._items_at < self.cache_ttl
            ):
                return self._items
            items = await self.client.get_items()
            self._items = items
            self._items_at = time.time()
            return items

    async def _get_craftables(self, force: bool = False) -> list[dict]:
        if (
            not force
            and self._craftables
            and time.time() - self._craftables_at < self.cache_ttl * 2
        ):
            return self._craftables
        craftables = await self.client.get_craftables()
        self._craftables = craftables
        self._craftables_at = time.time()
        return craftables

    # ------------------------------------------------------------------ 指令
    @filter.command_group("ae")
    def ae(self):
        """GTNH 赛博监工指令组"""

    @ae.command("help")
    async def help(self, event: AstrMessageEvent):
        """查看帮助"""
        yield event.plain_result(
            "GTNH 赛博监工指令：\n"
            "/ae status              查看后端和 OC 在线状态\n"
            "/ae items [关键词] [页]  查看 AE 物品（不填关键词显示总数和前几页）\n"
            "/ae find <关键词>       搜索物品，显示注册名/damage/数量\n"
            "/ae craft <物品> [数量] [CPU]  远程下单合成\n"
            "/ae cpu                 查看 CPU 状态\n"
            "/ae cancel <CPU名>      取消该 CPU 当前合成\n"
            "/ae refresh             强制刷新物品缓存\n"
            "\n示例：\n"
            "/ae items potato\n"
            "/ae craft minecraft:potato 64\n"
            '/ae craft "Baked Potato" 8\n'
            "/ae craft minecraft:baked_potato 8 \"CPU-1\""
            "\n提示：默认用英文 label 或注册名搜索；"
            "在插件配置里填 item_data_url 后可以用中文名。"
        )

    @ae.command("status")
    async def status(self, event: AstrMessageEvent):
        """查看后端和 OC 在线状态"""
        if not self._allowed(event):
            yield event.plain_result("你没有权限使用该指令。")
            return
        try:
            meta = await self.client.meta()
            devices = await self.client.devices()
        except RemoteOCError as exc:
            yield event.plain_result(f"连接后端失败：{exc}")
            return

        lines = [
            f"后端版本：{meta.get('version', '?')}",
            f"在线客户端数：{meta.get('device_num', 0)}",
        ]
        if devices:
            for device in devices:
                active = device.get("active") or []
                last = active[-1].get("time", "?") if active else "无"
                lines.append(f"- {device.get('id') or '(未命名)'}  最后活动：{last}")
        else:
            lines.append("没有 OC 客户端在线，请检查游戏内 run.lua 是否在运行。")
        for result in self._send(event, "\n".join(lines)):
            yield result

    @ae.command("items")
    async def items(self, event: AstrMessageEvent):
        """查看 AE 物品"""
        if not self._allowed(event):
            yield event.plain_result("你没有权限使用该指令。")
            return
        tail = self._tail(event, "items")
        args = self._split(tail)
        page = 1
        if args and args[-1].isdigit():
            page = max(1, int(args.pop()))
        keyword = " ".join(args).strip()

        yield event.plain_result("正在向 OC 请求 AE 物品数据，请稍候…")
        await self._load_zh_names()
        try:
            items = await self._get_items()
        except RemoteOCError as exc:
            yield event.plain_result(f"获取物品失败：{exc}")
            return

        matched = [item for item in items if not keyword or self._match(item, keyword)]
        if keyword:
            matched.sort(key=lambda item: self._label(item).lower())
        else:
            matched.sort(key=lambda item: self._count(item), reverse=True)

        total_count = sum(self._count(item) for item in items)
        header = f"AE 物品种类：{len(items)}，总数量：{total_count}"
        if keyword:
            header += f"\n关键词「{keyword}」匹配 {len(matched)} 种"
        if not matched:
            yield event.plain_result(header + "\n没有匹配的物品。")
            return

        pages = max(1, (len(matched) + self.page_size - 1) // self.page_size)
        page = min(page, pages)
        start = (page - 1) * self.page_size
        lines = [header, ""]
        for item in matched[start : start + self.page_size]:
            label = self._label(item)
            count = self._count(item)
            flags = ""
            if item.get("isCraftable"):
                flags += " [可合成]"
            if item.get("hasTag"):
                flags += " [NBT]"
            line = f"{label} ×{count}{flags}"
            if label != item.get("name"):
                line += f"  ({self._ident(item)})"
            lines.append(line)
        lines.append("")
        lines.append(f"第 {page}/{pages} 页，用法：/ae items [关键词] [页码]")
        if len(matched) > self.page_size:
            lines.append("提示：加关键词可以缩小范围。")
        for result in self._send(event, "\n".join(lines)):
            yield result

    @ae.command("find")
    async def find(self, event: AstrMessageEvent):
        """搜索物品"""
        if not self._allowed(event):
            yield event.plain_result("你没有权限使用该指令。")
            return
        keyword = self._tail(event, "find").strip()
        if not keyword:
            yield event.plain_result("用法：/ae find <关键词>")
            return
        yield event.plain_result(f"正在搜索「{keyword}」…")
        await self._load_zh_names()
        try:
            items = await self._get_items()
        except RemoteOCError as exc:
            yield event.plain_result(f"获取物品失败：{exc}")
            return

        matched = [item for item in items if self._match(item, keyword)]
        if not matched:
            yield event.plain_result(f"没有找到包含「{keyword}」的物品。")
            return
        matched.sort(key=lambda item: self._label(item).lower())
        lines = [f"「{keyword}」匹配 {len(matched)} 种："]
        for item in matched[:30]:
            flags = " [可合成]" if item.get("isCraftable") else ""
            lines.append(
                f"- {self._label(item)} ×{self._count(item)}{flags}  "
                f"{self._ident(item)}"
            )
        if len(matched) > 30:
            lines.append(f"……还有 {len(matched) - 30} 种未显示，请加更精确的关键词。")
        lines.append("下单：/ae craft <注册名或完整名称> [数量] [CPU]")
        for result in self._send(event, "\n".join(lines)):
            yield result

    @ae.command("craft")
    async def craft(self, event: AstrMessageEvent):
        """远程下单合成"""
        if not self._allowed(event):
            yield event.plain_result("你没有权限使用该指令。")
            return
        tail = self._tail(event, "craft")
        args = self._split(tail)
        if not args:
            yield event.plain_result(
                "用法：/ae craft <物品名或注册名> [数量] [CPU名]\n"
                "示例：/ae craft minecraft:potato 64\n"
                '/ae craft "Baked Potato" 8 "CPU-1"'
            )
            return

        query = args[0]
        amount = 1
        cpu = ""
        rest = args[1:]
        if rest and rest[0].isdigit():
            amount = int(rest[0])
            rest = rest[1:]
        if rest:
            cpu = " ".join(rest).strip()
        if amount <= 0:
            yield event.plain_result("数量必须大于 0。")
            return

        yield event.plain_result(f"正在查找「{query}」并准备下单…")
        await self._load_zh_names()
        try:
            items = await self._get_items()
        except RemoteOCError as exc:
            yield event.plain_result(f"获取物品失败：{exc}")
            return

        exact = [item for item in items if self._exact(item, query)]
        candidates = exact or [item for item in items if self._match(item, query)]

        if not candidates:
            # 可能物品不在网络里，但在可合成列表中
            try:
                craftables = await self._get_craftables()
            except RemoteOCError:
                craftables = []
            exact = [item for item in craftables if self._exact(item, query)]
            candidates = exact or [
                item for item in craftables if self._match(item, query)
            ]

        if not candidates:
            yield event.plain_result(
                f"没有找到「{query}」。可以先用 /ae find 关键词 确认名称。"
            )
            return

        if len(candidates) > 1:
            lines = [f"「{query}」匹配到 {len(candidates)} 个物品，请用更精确的名称或注册名："]
            for item in candidates[:10]:
                lines.append(
                    f"- {self._label(item)}  {self._ident(item)}  "
                    f"库存 {self._count(item)}"
                )
            lines.append("示例：/ae craft minecraft:potato 64")
            for result in self._send(event, "\n".join(lines)):
                yield result
            return

        item = candidates[0]
        name = str(item.get("name") or "")
        damage = int(item.get("damage", 0) or 0)
        # 只有流体液滴需要 label；普通物品传 label 反而可能匹配不到
        label = item.get("label") if name == "ae2fc:fluid_drop" else None
        try:
            result = await self.client.craft(
                name=name,
                damage=damage,
                amount=amount,
                cpu=cpu or None,
                label=str(label) if label else None,
            )
        except RemoteOCError as exc:
            yield event.plain_result(f"下单失败：{exc}")
            return

        message = result.get("message")
        if message != "success":
            yield event.plain_result(f"下单失败：{message or '未知错误'}")
            return

        data = result.get("data") or {}
        item_data = data.get("item") or {}
        label = item_data.get("label") or item_data.get("name") or name
        lines = [f"已提交合成：{label} ×{amount}"]
        if data.get("failed"):
            lines.append("状态：合成失败（可能缺少材料）")
        elif (data.get("done") or {}).get("result"):
            lines.append("状态：已完成")
        elif (data.get("canceled") or {}).get("result"):
            why = (data.get("canceled") or {}).get("why") or "未知原因"
            lines.append(f"状态：已取消（{why}）")
        elif data.get("computing"):
            lines.append("状态：正在计算")
        else:
            lines.append("状态：已提交，等待 CPU 执行")
        if cpu:
            lines.append(f"指定 CPU：{cpu}")
        for result_text in self._send(event, "\n".join(lines)):
            yield result_text

    @ae.command("cpu")
    async def cpu(self, event: AstrMessageEvent):
        """查看 CPU 状态"""
        if not self._allowed(event):
            yield event.plain_result("你没有权限使用该指令。")
            return
        yield event.plain_result("正在读取 CPU 状态…")
        try:
            cpus = await self.client.get_cpus()
        except RemoteOCError as exc:
            yield event.plain_result(f"获取 CPU 失败：{exc}")
            return
        if not cpus:
            yield event.plain_result("AE 网络里没有找到 CPU。")
            return
        lines = [f"CPU 数量：{len(cpus)}"]
        for item in cpus:
            name = item.get("name") or "(未命名)"
            busy = "忙碌" if item.get("busy") else "空闲"
            storage = item.get("storage")
            coprocessors = item.get("coprocessors")
            line = f"- {name}：{busy}"
            if coprocessors is not None:
                line += f"，协处理器 {coprocessors}"
            if storage is not None:
                line += f"，存储 {storage}"
            lines.append(line)
        for result in self._send(event, "\n".join(lines)):
            yield result

    @ae.command("cancel")
    async def cancel(self, event: AstrMessageEvent):
        """取消指定 CPU 的合成任务"""
        if not self._allowed(event):
            yield event.plain_result("你没有权限使用该指令。")
            return
        cpu = self._tail(event, "cancel").strip()
        if not cpu:
            yield event.plain_result("用法：/ae cancel <CPU名>")
            return
        try:
            result = await self.client.cancel_crafting(cpu)
        except RemoteOCError as exc:
            yield event.plain_result(f"取消失败：{exc}")
            return
        yield event.plain_result(str(result.get("message") or result))

    @ae.command("refresh")
    async def refresh(self, event: AstrMessageEvent):
        """强制刷新物品缓存"""
        if not self._allowed(event):
            yield event.plain_result("你没有权限使用该指令。")
            return
        yield event.plain_result("正在刷新物品和可合成列表…")
        await self._load_zh_names()
        try:
            items = await self._get_items(force=True)
            await self._get_craftables(force=True)
        except RemoteOCError as exc:
            yield event.plain_result(f"刷新失败：{exc}")
            return
        yield event.plain_result(f"刷新完成，当前 AE 网络共 {len(items)} 种物品。")

"""RemoteOC-GTNH-AE2 后端的异步 API 客户端。

这个模块不依赖 AstrBot，方便单独测试。
"""

from __future__ import annotations

import asyncio
import json
import uuid
from typing import Any

import aiohttp


class RemoteOCError(Exception):
    """后端返回错误、连接失败或任务超时时抛出。"""


class RemoteOCClient:
    def __init__(
        self,
        base_url: str,
        token: str,
        client_id: str = "client_01",
        request_timeout: int = 60,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.client_id = client_id
        self.request_timeout = request_timeout
        self._session: aiohttp.ClientSession | None = None
        self._cached_task_lock = asyncio.Lock()

    # ------------------------------------------------------------------ HTTP
    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30),
                headers={"X-Server-Token": self.token},
            )
        return self._session

    async def close(self) -> None:
        if self._session and not self._session.closed:
            await self._session.close()

    async def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        session = await self._get_session()
        url = f"{self.base_url}{path}"
        try:
            async with session.request(method, url, **kwargs) as response:
                text = await response.text()
        except aiohttp.ClientError as exc:
            raise RemoteOCError(f"无法连接后端 {self.base_url}: {exc}") from exc
        except asyncio.TimeoutError as exc:
            raise RemoteOCError(f"请求后端超时: {self.base_url}") from exc

        try:
            payload = json.loads(text)
        except json.JSONDecodeError as exc:
            raise RemoteOCError(
                f"后端返回了非 JSON 内容（HTTP {response.status}）: {text[:200]}"
            ) from exc

        if payload.get("code") != 200:
            raise RemoteOCError(f"{payload.get('code')}: {payload.get('message')}")
        return payload.get("data")

    # --------------------------------------------------------------- 基础接口
    async def fetch_json(self, url: str, timeout: int = 60) -> Any:
        """下载一个外部 JSON（用于前端的中文物品名数据）。

        使用独立的 session，避免把后端 token 发给第三方地址。
        """
        try:
            async with aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=timeout)
            ) as session:
                async with session.get(url) as response:
                    response.raise_for_status()
                    return await response.json(content_type=None)
        except (aiohttp.ClientError, asyncio.TimeoutError, ValueError) as exc:
            raise RemoteOCError(f"下载 {url} 失败: {exc}") from exc

    async def meta(self) -> dict:
        return await self._request("GET", "/api/info/meta") or {}

    async def devices(self) -> list:
        return await self._request("GET", "/api/info/devices") or []

    async def task_status(self, task_id: str, remove: bool = False) -> dict | None:
        params = {
            "task_id": task_id,
            "remove": "true" if remove else "false",
            "use_gzip": "false",
        }
        return await self._request("GET", "/api/task/status", params=params)

    async def trigger_task(self, task_id: str) -> None:
        await self._request(
            "POST",
            "/api/task/task",
            json={"task_id": task_id, "client_id": self.client_id},
        )

    async def add_task(self, commands: list[str], task_id: str | None = None) -> str:
        task_id = task_id or f"astrbot-{uuid.uuid4().hex[:12]}"
        await self._request(
            "POST",
            "/api/task/add",
            json={
                "task_id": task_id,
                "client_id": self.client_id,
                "commands": commands,
            },
        )
        return task_id

    # --------------------------------------------------------------- 任务等待
    async def _wait_task(
        self,
        task_id: str,
        previous_completed: str | None,
        timeout: int,
        remove: bool = False,
    ) -> Any:
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        last_status = None
        while loop.time() < deadline:
            try:
                task = await self.task_status(task_id, remove=remove)
            except RemoteOCError as exc:
                # 404 表示任务还没创建/已被删除，继续等；其它错误（如 403）直接抛出
                if "404" not in str(exc):
                    raise
                task = None
            if task:
                last_status = task
                if (
                    task.get("status") == "completed"
                    and task.get("completed_time") != previous_completed
                ):
                    return task.get("result")
            await asyncio.sleep(1)
        raise RemoteOCError(
            f"任务 {task_id} 超时（当前状态: {last_status.get('status') if last_status else '未知'}）"
        )

    async def run_cached_task(self, task_id: str, timeout: int | None = None) -> Any:
        """触发 task_config 中的缓存任务，并等待本次执行完成。"""
        timeout = timeout or self.request_timeout
        async with self._cached_task_lock:
            previous = None
            try:
                previous = await self.task_status(task_id)
            except RemoteOCError as exc:
                # 任务不存在时后端返回 404；其它错误直接抛出
                if "404" not in str(exc):
                    raise
            previous_completed = (
                previous.get("completed_time") if isinstance(previous, dict) else None
            )
            await self.trigger_task(task_id)
            return await self._wait_task(task_id, previous_completed, timeout)

    async def run_command(self, command: str, timeout: int | None = None) -> Any:
        """提交一条 Lua 命令并等待结果。"""
        timeout = timeout or self.request_timeout
        task_id = await self.add_task([command])
        return await self._wait_task(task_id, None, timeout, remove=True)

    # --------------------------------------------------------------- 结果解析
    @staticmethod
    def parse_command_result(result: Any) -> Any:
        """非分块任务返回的是「每条命令一个 JSON 字符串」的列表。"""
        if isinstance(result, list):
            parsed = []
            for entry in result:
                if isinstance(entry, str):
                    try:
                        parsed.append(json.loads(entry))
                    except json.JSONDecodeError:
                        parsed.append(entry)
                else:
                    parsed.append(entry)
            return parsed[0] if len(parsed) == 1 else parsed
        return result

    @classmethod
    def parse_item_list(cls, result: Any) -> list[dict]:
        """分块任务（getAllItems）返回的已经是物品对象数组。"""
        if isinstance(result, list) and (not result or isinstance(result[0], dict)):
            return result
        if isinstance(result, dict) and "name" in result:
            return [result]
        parsed = cls.parse_command_result(result)
        if isinstance(parsed, dict):
            data = parsed.get("data")
            if isinstance(data, list):
                return data
        if isinstance(parsed, list):
            return parsed
        return []

    @classmethod
    def _list_from_result(cls, result: Any) -> list[dict]:
        parsed = cls.parse_command_result(result)
        if isinstance(parsed, dict):
            data = parsed.get("data")
            if isinstance(data, list):
                return data
        if isinstance(parsed, list):
            return parsed
        return []

    # --------------------------------------------------------------- 业务方法
    async def get_items(self, timeout: int | None = None) -> list[dict]:
        result = await self.run_cached_task("getAllItems", timeout)
        return self.parse_item_list(result)

    async def get_craftables(self, timeout: int | None = None) -> list[dict]:
        result = await self.run_cached_task("getAllCraftables", timeout)
        return self._list_from_result(result)

    async def get_cpus(self, timeout: int | None = None) -> list[dict]:
        result = await self.run_cached_task("getCpuList", timeout)
        return self._list_from_result(result)

    @staticmethod
    def lua_quote(value: str) -> str:
        text = str(value)
        text = text.replace("\\", "\\\\").replace("'", "\\'")
        text = text.replace("\n", "\\n").replace("\r", "\\r")
        return f"'{text}'"

    async def craft(
        self,
        name: str,
        damage: int,
        amount: int = 1,
        cpu: str | None = None,
        label: str | None = None,
        timeout: int | None = None,
    ) -> dict:
        args = [self.lua_quote(name), str(int(damage)), str(int(amount))]
        if cpu or label:
            args.append(self.lua_quote(cpu) if cpu else "nil")
        if label:
            args.append(self.lua_quote(label))
        command = "return ae.requestItem(" + ", ".join(args) + ")"
        result = await self.run_command(command, timeout)
        parsed = self.parse_command_result(result)
        if isinstance(parsed, dict):
            return parsed
        return {"message": str(parsed)}

    async def cancel_crafting(self, cpu_name: str, timeout: int | None = None) -> dict:
        command = f"return ae.cancelCraftingByCpuName({self.lua_quote(cpu_name)})"
        result = await self.run_command(command, timeout)
        parsed = self.parse_command_result(result)
        if isinstance(parsed, dict):
            return parsed
        return {"message": str(parsed)}
